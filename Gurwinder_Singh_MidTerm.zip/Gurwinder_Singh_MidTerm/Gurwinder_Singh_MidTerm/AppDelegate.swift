//
//  AppDelegate.swift
//  Gurwinder_Singh_MidTerm
//
//  Created by Gurwinder Singh on 2023-10-04.
//
import SwiftUI
import UserNotifications

class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
            if granted {
                print("Notification authorization approved")
            } else {
                print("Notification authorization declined")
            }
        }
        UNUserNotificationCenter.current().delegate = self
        return true
    }
}
