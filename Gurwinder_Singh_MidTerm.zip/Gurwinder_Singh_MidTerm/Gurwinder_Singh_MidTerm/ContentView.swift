//
//  ContentView.swift
//  Gurwinder_Singh_MidTerm
//
//  Created by Gurwinder Singh on 2023-10-04.

import SwiftUI
import UserNotifications

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Gurwinder Singh")
                .font(.title)
                .fontWeight(.bold)
                .padding(.bottom, 12)
            
            Text("Student ID: 200557497")
                .font(.headline)
                .fontWeight(.bold)
                .padding(.bottom, 20)
            
            Spacer()
            
            Button(action: {
                let content = UNMutableNotificationContent()
                content.title = "Just So You Know"
                content.body = "We Are Out of Food"
                
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 15, repeats: false)
                
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                
                UNUserNotificationCenter.current().add(request) { error in
                    if let error = error {
                        print("Error triggering notification: \(error)")
                    } else {
                        print("Notification triggered successfully")
                    }
                }
            }) {
                Text("Hungry?")
                    .fontWeight(.bold)
                    .font(.headline)
                    .padding()
                    .background(Color.purple)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.top, 15)
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
