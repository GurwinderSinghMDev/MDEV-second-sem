//
//  Gurwinder_Singh_MidTermApp.swift
//  Gurwinder_Singh_MidTerm
//
//  Created by Gurwinder Singh on 2023-10-04.
//
import SwiftUI

@main
struct Gurwinder_Singh_MIdTermApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
