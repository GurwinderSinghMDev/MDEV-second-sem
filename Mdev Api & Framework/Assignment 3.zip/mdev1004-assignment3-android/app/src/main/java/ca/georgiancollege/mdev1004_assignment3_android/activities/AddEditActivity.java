// AddEditActivity.java
// Harmandeep Kaur
// Student id: 200560512
// Date: 12/11/2023
package ca.georgiancollege.mdev1004_assignment3_android.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.UUID;

import ca.georgiancollege.mdev1004_assignment3_android.R;
import ca.georgiancollege.mdev1004_assignment3_android.models.Book;
import ca.georgiancollege.mdev1004_assignment3_android.services.BookService;
import ca.georgiancollege.mdev1004_assignment3_android.services.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddEditActivity extends AppCompatActivity
{
    public static String EXTRA_BOOK_ID = "book";

    // Fields
    private EditText titleEditText;
    private EditText isbnEditText;
    private EditText ratingEditText;
    private EditText authorEditText;
    private EditText genreEditText;
    private TextView headerTextView;
    private Book book;

    // To keep track if the book is being edited
    private boolean isEditingMode;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        // initialization
        titleEditText = findViewById(R.id.editTextTitle);
        isbnEditText = findViewById(R.id.editTextIsbn);
        ratingEditText = findViewById(R.id.editTextRating);
        authorEditText = findViewById(R.id.editTextAuthor);
        genreEditText = findViewById(R.id.editTextGenre);
        headerTextView = findViewById(R.id.textViewHeader);
        // Set click listeners for buttons
        Button saveButton = findViewById(R.id.buttonSave);
        saveButton.setOnClickListener(v -> saveBook());

        Button cancelButton = findViewById(R.id.buttonCancel);
        cancelButton.setOnClickListener(v -> finish());

        // Set click listener for the delete button
        Button deleteButton = findViewById(R.id.buttonDelete);
        deleteButton.setOnClickListener(v -> deleteBook());

        // Check if in editing mode
        if (getIntent().hasExtra(EXTRA_BOOK_ID))
        {
            isEditingMode = true;
            this.book = (Book) getIntent().getSerializableExtra(EXTRA_BOOK_ID);
            showBookDetails();
            headerTextView.setText("Edit Book");
        } else
        {
            headerTextView.setText("Add Book");
            deleteButton.setVisibility(View.GONE);
        }

    }

    private void showBookDetails()
    {
        titleEditText.setText(book.getBookName());
        isbnEditText.setText(book.getIsbn());
        ratingEditText.setText(String.valueOf(book.getRating()));
        authorEditText.setText(book.getAuthor());
        genreEditText.setText(book.getGenre());
    }

    private void saveBook()
    {
        String title = titleEditText.getText().toString().trim();
        String isbn = isbnEditText.getText().toString().trim();
        String ratingString = ratingEditText.getText().toString().trim();
        String author = authorEditText.getText().toString().trim();
        String genre = genreEditText.getText().toString().trim();


        if (title.isEmpty() || isbn.isEmpty() || ratingString.isEmpty() ||
                author.isEmpty() || genre.isEmpty())
        {
            Toast.makeText(this, "Please fill in all the fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        double rating = Double.parseDouble(ratingString);

        // If book is being edited set current id or create random UUID
        Book requestBody = new Book(isEditingMode ? book.get_id() : UUID.randomUUID().toString(), title, isbn, rating, author, genre);

        BookService bookService = RetrofitClientInstance.getRetrofitInstance().create(BookService.class);
        Call<Void> call;
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String authToken = preferences.getString("AuthToken", "");

        // Add the AuthToken to the request headers
        String authorizationHeader = "Bearer " + authToken;

        if (isEditingMode)
        {
            call = bookService.updateBook(authorizationHeader, book.get_id(), requestBody);
        } else
        {
            call = bookService.addBook(authorizationHeader, requestBody);
        }

        call.enqueue(new Callback<Void>()
        {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response)
            {
                Log.d("ADD ", response.toString());
                if (response.isSuccessful())
                {
                    // Book updated or created successfully
                    finish();
                } else
                {
                    // Handle the error here (e.g., show a Toast)
                    Toast.makeText(AddEditActivity.this, "Failed to update book.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t)
            {
                // Handle the error here (e.g., show a Toast)
                Toast.makeText(AddEditActivity.this, "Failed to update book. Error: " + t.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void deleteBook()
    {
        if (isEditingMode && book != null)
        {
            // Book exists and we are in editing mode, proceed with deletion

            BookService bookService = RetrofitClientInstance.getRetrofitInstance().create(BookService.class);

            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
            String authToken = preferences.getString("AuthToken", "");

            // Add the AuthToken to the request headers
            String authorizationHeader = "Bearer " + authToken;
            Call<Void> call = bookService.deleteBook(authorizationHeader, book.get_id());

            call.enqueue(new Callback<Void>()
            {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response)
                {
                    if (response.isSuccessful())
                    {
                        // Book deleted successfully
                        finish();
                    } else
                    {
                        // Handle the error here (e.g., show a Toast)
                        Toast.makeText(AddEditActivity.this, "Failed to delete book.", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t)
                {
                    // Handle the error here (e.g., show a Toast)
                    Toast.makeText(AddEditActivity.this, "Failed to delete book. Error: " + t.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            });
        } else
        {
            // Not in editing mode or book is null, no book to delete
            finish();
        }
    }

}