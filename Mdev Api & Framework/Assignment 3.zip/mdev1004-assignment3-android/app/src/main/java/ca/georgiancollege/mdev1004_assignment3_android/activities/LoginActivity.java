// LoginActivity.java
// Gurwinder Singh
// Student id: 200557497
// Date: 12/11/2023
package ca.georgiancollege.mdev1004_assignment3_android.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

import ca.georgiancollege.mdev1004_assignment3_android.models.LoginResponse;
import ca.georgiancollege.mdev1004_assignment3_android.models.UserLoginData;
import ca.georgiancollege.mdev1004_assignment3_android.services.BookService;
import ca.georgiancollege.mdev1004_assignment3_android.R;
import ca.georgiancollege.mdev1004_assignment3_android.services.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText usernameEditText = findViewById(R.id.usernameEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);

        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(view -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            loginUser(username, password);
        });

        Button registerButton = findViewById(R.id.registerButton);
        registerButton.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private void loginUser(String username, String password) {
        BookService bookService = RetrofitClientInstance.getRetrofitInstance().create(BookService.class);

        UserLoginData userLoginData = new UserLoginData(username, password);

        Call<LoginResponse> call = bookService.loginUser(userLoginData);
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful()) {
                    LoginResponse loginResponse = response.body();
                    if (loginResponse != null && loginResponse.isSuccess()) {
                        // User logged in successfully
                        // Save the token in SharedPreferences for later use
                        String token = loginResponse.getToken();
                        saveAuthToken(token);

                        // Proceed to the next screen, for example, start the CRUDActivity
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        // Login failed
                        Toast.makeText(LoginActivity.this, "Login failed. Please check your credentials.",
                                Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Error handling for unsuccessful login
                    if (response.errorBody() != null) {
                        try {
                            String errorMessage = response.errorBody().string();
                            Toast.makeText(LoginActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                // Error handling for network failures
                Toast.makeText(LoginActivity.this, "Failed to connect to the server." + t.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to save the auth token in SharedPreferences
    private void saveAuthToken(String token) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("AuthToken", token);
        editor.apply();
    }
}