// MainActivity.java
// Gurleen Kaur
// Student id: 200555436
// Date: 12/11/2023
package ca.georgiancollege.mdev1004_assignment3_android.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Toast;

import java.util.List;

import ca.georgiancollege.mdev1004_assignment3_android.R;
import ca.georgiancollege.mdev1004_assignment3_android.adapters.BookAdapter;
import ca.georgiancollege.mdev1004_assignment3_android.models.Book;
import ca.georgiancollege.mdev1004_assignment3_android.services.BookService;
import ca.georgiancollege.mdev1004_assignment3_android.services.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private BookAdapter bookAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        bookAdapter = new BookAdapter(null, this);
        recyclerView.setAdapter(bookAdapter);

        findViewById(R.id.addBookButton).setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.logoutButton).setOnClickListener(view -> logout());
    }

    private void logout() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        fetchBooks();
    }

    private void fetchBooks() {

        BookService bookService = RetrofitClientInstance.getRetrofitInstance().create(BookService.class);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String authToken = preferences.getString("AuthToken", "");

        // Add the AuthToken to the request headers
        String authorizationHeader = "Bearer " + authToken;
        Call<List<Book>> call = bookService.getBooks(authorizationHeader);
        call.enqueue(new Callback<List<Book>>() {
            @Override
            public void onResponse(Call<List<Book>> call, Response<List<Book>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Book> books = response.body();
                        if (books != null && !books.isEmpty()) {
                            bookAdapter.setBooks(books);
                        } else {
                            displayErrorMessage("No books available.");
                        }
                } else {
                    displayErrorMessage("Error: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<Book>> call, Throwable t) {
                displayErrorMessage("Error: " + t.getMessage());
            }
        });
    }

    private void displayErrorMessage(String message) {
        Toast.makeText(this, "Error: " + message, Toast.LENGTH_SHORT).show();
    }
}
