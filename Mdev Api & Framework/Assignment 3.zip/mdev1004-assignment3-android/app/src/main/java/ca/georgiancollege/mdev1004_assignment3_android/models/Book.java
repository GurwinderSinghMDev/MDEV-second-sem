// Book.java
// Gurleen Kaur
// Student id: 200555436
// Date: 12/11/2023
package ca.georgiancollege.mdev1004_assignment3_android.models;

import java.io.Serializable;
import java.util.List;

public class Book implements Serializable {
    private String _id;
    private String bookName;
    private String isbn;
    private double rating;
    private String author;
    private String genre;

    // Constructors
    public Book() {
    }

    public Book(String _id, String bookName, String isbn, double rating, String author, String genre) {
        this._id = _id;
        this.bookName = bookName;
        this.isbn = isbn;
        this.rating = rating;
        this.author = author;
        this.genre = genre;
    }

    // Getters and Setters
    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    // toString method for better representation
    @Override
    public String toString() {
        return "Book{" +
                "_id='" + _id + '\'' +
                ", bookName='" + bookName + '\'' +
                ", isbn='" + isbn + '\'' +
                ", rating=" + rating +
                ", author='" + author + '\'' +
                ", genre='" + genre + '\'' +
                '}';
    }
}
