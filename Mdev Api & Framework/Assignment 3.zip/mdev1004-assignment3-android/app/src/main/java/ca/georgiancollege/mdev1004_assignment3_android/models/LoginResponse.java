// LoginResponse.java
// Gurwinder Singh
// Student id: 200557497
// Date: 12/11/2023
package ca.georgiancollege.mdev1004_assignment3_android.models;

import com.squareup.moshi.Json;

public class LoginResponse {

    @Json(name = "success")
    private boolean success;

    @Json(name = "token")
    private String token;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
