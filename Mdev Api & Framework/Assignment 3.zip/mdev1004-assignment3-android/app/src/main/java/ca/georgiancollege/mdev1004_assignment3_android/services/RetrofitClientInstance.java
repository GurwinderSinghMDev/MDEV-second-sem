// RetrofitClientInstance.java
// Gurwinder Singh
// Student id: 200557497
// Date: 12/11/2023
package ca.georgiancollege.mdev1004_assignment3_android.services;

import retrofit2.Retrofit;
import retrofit2.converter.moshi.MoshiConverterFactory;

public class RetrofitClientInstance {

    private static final String BASE_URL = "https://mdev1004-assignment3-api.onrender.com";

    private static Retrofit retrofit;

    public static Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(MoshiConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
