"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let localURI = "mongodb://127.0.0.1:27017/books";
let remoteURI = "mongodb+srv://kohli:test123@cluster0.synbtw1.mongodb.net/books";
let secret = "secret";
exports.default = {
    localURI: localURI,
    remoteURI: remoteURI,
    secret: secret,
};
//# sourceMappingURL=db.js.map