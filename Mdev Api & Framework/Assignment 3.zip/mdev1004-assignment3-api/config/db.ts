// db.ts
// Gurwinder Singh
// Student id: 200557497
// Date: 11/11/2023

// Variables to store database connection info
let localURI = "mongodb://127.0.0.1:27017/books";
let remoteURI = "mongodb+srv://kohli:test123@cluster0.synbtw1.mongodb.net/books";
let secret = "secret";

export default {
    localURI: localURI,
    remoteURI: remoteURI,
    secret: secret,
};
