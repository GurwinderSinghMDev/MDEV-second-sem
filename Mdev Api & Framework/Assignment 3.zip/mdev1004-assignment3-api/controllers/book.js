"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteBook = exports.updateBook = exports.addBook = exports.findBookById = exports.listBooks = void 0;
const book_1 = __importDefault(require("../models/book"));
function listBooks(req, res, next) {
    book_1.default.find({})
        .then(function (data) {
        res.json(data);
    })
        .catch(function (err) {
        res.json({ error: "There was a error in finding books" });
        console.error(err);
    });
}
exports.listBooks = listBooks;
function findBookById(req, res, next) {
    const { id } = req.params;
    book_1.default.findById(id)
        .then(function (data) {
        res.json(data);
    })
        .catch(function (err) {
        res.json({ error: "There was a error fetching your book" });
        console.error(err);
    });
}
exports.findBookById = findBookById;
function addBook(req, res, next) {
    const { bookName, isbn, rating, author, genre } = req.body;
    book_1.default.create({ bookName, isbn, rating, author, genre })
        .then(function (data) {
        res.json(data);
    })
        .catch(function (err) {
        res.json({
            error: "There was a error in adding new book, please make sure all book information is provided",
        });
        console.error(err);
    });
}
exports.addBook = addBook;
function updateBook(req, res, next) {
    const { id } = req.params;
    const { bookName, isbn, rating, author, genre } = req.body;
    book_1.default.findByIdAndUpdate(id, { _id: id, bookName, isbn, rating, author, genre })
        .then(function (data) {
        res.json({ _id: id, bookName, isbn, rating, author, genre });
    })
        .catch(function (err) {
        res.json({ error: "There was a error updating the book" });
        console.error(err);
    });
}
exports.updateBook = updateBook;
function deleteBook(req, res, next) {
    const { id } = req.params;
    book_1.default.findByIdAndDelete(id)
        .then(function (data) {
        res.json(data);
    })
        .catch(function (err) {
        res.json({ error: "There was a error in deleting the book" });
        console.error(err);
    });
}
exports.deleteBook = deleteBook;
//# sourceMappingURL=book.js.map