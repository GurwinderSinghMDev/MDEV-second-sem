// book.ts
// Gurleen Kaur
// Student id: 200555436
// Date: 12/11/2023

import { Request, Response, NextFunction } from "express";

import Book from "../models/book";

// Function to list all books
export function listBooks(req: Request, res: Response, next: NextFunction): void {
    // Empty search to get all books
    Book.find({})
        .then(function (data) {
            // Responding with all books
            res.json(data);
        })
        .catch(function (err) {
            // Responding with error
            res.json({ error: "There was a error in finding books" });
            // Logging all books
            console.error(err);
        });
}

// Function to find book by id
export function findBookById(req: Request, res: Response, next: NextFunction): void {
    // Getting id from url param
    const { id } = req.params;

    // Finding book by id
    Book.findById(id)
        .then(function (data) {
            // Responding with found book
            res.json(data);
        })
        .catch(function (err) {
            // Responding with error
            res.json({ error: "There was a error fetching your book" });
            // Logging all books
            console.error(err);
        });
}

// Function to add a new book
export function addBook(req: Request, res: Response, next: NextFunction): void {
    // Destructuring book information from request body
    const { bookName, isbn, rating, author, genre } = req.body;

    // Creating book with book information
    Book.create({ bookName, isbn, rating, author, genre })
        .then(function (data) {
            // Responding with created book
            res.json(data);
        })
        .catch(function (err) {
            // Responding with error
            res.json({
                error: "There was a error in adding new book, please make sure all book information is provided",
            });
            // Logging all books
            console.error(err);
        });
}

// Function to update book
export function updateBook(req: Request, res: Response, next: NextFunction): void {
    // Getting id from url param
    const { id } = req.params;
    // Destructuring book information from request body
    const { bookName, isbn, rating, author, genre } = req.body;
    // Updating book with passed to new data
    Book.findByIdAndUpdate(id, { _id: id, bookName, isbn, rating, author, genre })
        .then(function (data) {
            // Responding with updated book
            res.json({ _id: id, bookName, isbn, rating, author, genre });
        })
        .catch(function (err) {
            // Responding with error
            res.json({ error: "There was a error updating the book" });
            // Logging all books
            console.error(err);
        });
}

// Function to delete book
export function deleteBook(req: Request, res: Response, next: NextFunction): void {
    // Getting id from url param
    const { id } = req.params;
    // Deleting book with passed id
    Book.findByIdAndDelete(id)
        .then(function (data) {
            // Responding with deleted book
            res.json(data);
        })
        .catch(function (err) {
            // Responding with error
            res.json({ error: "There was a error in deleting the book" });
            // Logging all books
            console.error(err);
        });
}
