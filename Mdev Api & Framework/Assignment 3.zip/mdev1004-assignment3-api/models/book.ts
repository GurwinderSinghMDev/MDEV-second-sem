// user.ts
// Gurleen Kaur
// Student id: 200555436
// Date: 11/11/2023

import { Schema, model } from "mongoose";

// Interface for book data type
interface IBook {
    bookName: string;
    isbn: string;
    rating: number;
    author: string;
    genre: string;
}

// Creating Schema for book
let bookSchema = new Schema<IBook>({
    bookName: String,
    isbn: String,
    rating: Number,
    author: String,
    genre: String,
});

// Syncing book schema with database
let Book = model<IBook>("Book", bookSchema);

export default Book;
