"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
let router = express_1.default.Router();
const passport_1 = __importDefault(require("passport"));
const book_1 = require("../controllers/book");
router.get("/list", passport_1.default.authenticate("jwt", { session: false }), book_1.listBooks);
router.get("/find/:id", passport_1.default.authenticate("jwt", { session: false }), book_1.findBookById);
router.post("/add", passport_1.default.authenticate("jwt", { session: false }), book_1.addBook);
router.post("/update/:id", passport_1.default.authenticate("jwt", { session: false }), book_1.updateBook);
router.delete("/delete/:id", passport_1.default.authenticate("jwt", { session: false }), book_1.deleteBook);
exports.default = router;
//# sourceMappingURL=index.js.map