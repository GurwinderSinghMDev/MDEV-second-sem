// BookActivity.java
// Gurleen Kaur
// Student id: 200555436
// Date: 02/12/2023
package ca.georgiancollege.mdev1004_assignment4_android.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import ca.georgiancollege.mdev1004_assignment4_android.R;
import ca.georgiancollege.mdev1004_assignment4_android.activities.AddEditActivity;
import ca.georgiancollege.mdev1004_assignment4_android.models.Book;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {
    private List<Book> books;
    private final Context context;

    public BookAdapter(List<Book> books, Context context) {
        this.books = books;
        this.context = context;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.book_item, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        if (books == null) {
            return;
        }

        Book book = books.get(position);

        holder.titleTextView.setText(book.getBookName());
        holder.authorTextView.setText(book.getAuthor());
        holder.ratingTextView.setText(String.valueOf(book.getRating()));

        holder.linearLayoutContainer.setOnClickListener(view -> {
            Intent intent = new Intent(context, AddEditActivity.class);
            intent.putExtra("book", book);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return books != null ? books.size() : 0;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
        this.notifyDataSetChanged();
    }

    static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView authorTextView;
        TextView ratingTextView;
        LinearLayout linearLayoutContainer;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            authorTextView = itemView.findViewById(R.id.authorTextView);
            ratingTextView = itemView.findViewById(R.id.ratingTextView);
            linearLayoutContainer = itemView.findViewById(R.id.linearLayoutContainer);
        }
    }
}
