// LoginResponse.java
// Gurwinder Singh
// Student id: 200557497
// Date: 02/12/2023
package ca.georgiancollege.mdev1004_assignment4_android.models;

import com.squareup.moshi.Json;

public class LoginResponse {

    @Json(name = "success")
    private boolean success;

    @Json(name = "token")
    private String token;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
