// UserLoginData.java
// Gurwinder Singh
// Student id: 200557497
// Date: 02/12/2023
package ca.georgiancollege.mdev1004_assignment4_android.models;

public class UserLoginData {
    private String username;
    private String password;

    public UserLoginData(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
