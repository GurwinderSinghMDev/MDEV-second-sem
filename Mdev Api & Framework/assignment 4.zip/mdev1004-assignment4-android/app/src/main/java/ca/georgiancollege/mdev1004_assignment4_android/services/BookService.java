// BookService.java
// Gurwinder Singh
// Student id: 200557497
// Date: 02/12/2023
package ca.georgiancollege.mdev1004_assignment4_android.services;

import java.util.List;

import ca.georgiancollege.mdev1004_assignment4_android.models.Book;
import ca.georgiancollege.mdev1004_assignment4_android.models.LoginResponse;
import ca.georgiancollege.mdev1004_assignment4_android.models.UserLoginData;
import ca.georgiancollege.mdev1004_assignment4_android.models.UserRegistrationData;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface BookService {

    @GET("/list")
    Call<List<Book>> getBooks(@Header("Authorization") String authToken);

    @POST("/add")
    Call<Void> addBook(@Header("Authorization") String authToken, @Body Book book);

    @POST("/update/{bookId}")
    Call<Void> updateBook(@Header("Authorization") String authToken, @Path("bookId") String bookId,
            @Body Book book);

    @DELETE("/delete/{bookID}")
    Call<Void> deleteBook(@Header("Authorization") String authToken, @Path("bookID") String bookID);

    @POST("/auth/login")
    Call<LoginResponse> loginUser(@Body UserLoginData userLoginData);

    @POST("/auth/register")
    Call<Void> registerUser(@Body UserRegistrationData user);
}
