// app.ts
// Gurwinder Singh
// Student id: 200557497
// Date: 30/11/2023

import express from "express";
import path from "path";
import cookieParser from "cookie-parser";
import logger from "morgan";
import createError from "http-errors";

// modules for authentication
import session from "express-session";
import passport from "passport";
import passportLocal from "passport-local";

// modules for jwt support
import cors from "cors";
import passportJWT from "passport-jwt";

// define JWT aliases
let JWTStrategy = passportJWT.Strategy;
let ExtractJWT = passportJWT.ExtractJwt;

// authentication objects
let localStrategy = passportLocal.Strategy; // alias
import User from "./models/user";

import indexRouter from "./routes/index";
import authRouter from "./routes/auth";
import Book from "./models/book";

// Database modules
import mongoose from "mongoose";
import db from "./config/db";

// Connecting to database with remote URI
mongoose.connect(db.remoteURI);

// DB Connection Events
mongoose.connection.on("connected", () => {
    console.log(`Connected to MongoDB`);

    // Counting books in database
    Book.countDocuments({}).then((count) => {
        // If there are no books in database add three books
        if (count === 0) {
            Book.create([
                {
                    bookName: "A Game of Thrones",
                    isbn: "978-0553593716",
                    rating: 4.45,
                    author: "George R.R. Martin",
                    genre: "Fantasy",
                },
                {
                    bookName: "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe",
                    isbn: "978-0066238500",
                    rating: 4.21,
                    author: "C.S. Lewis",
                    genre: "Fantasy",
                },
                {
                    bookName: "The Hitchhiker's Guide to the Galaxy",
                    isbn: "978-0345391803",
                    rating: 4.21,
                    author: "Douglas Adams",
                    genre: "Science Fiction",
                },
            ]);
        }
    });
});

mongoose.connection.on("disconnected", () => {
    console.log("Disconnected from MongoDB");
});

let app = express();

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

// setup express session
app.use(
    session({
        secret: db.secret,
        saveUninitialized: false,
        resave: false,
    })
);

// initialize passport
app.use(passport.initialize());
app.use(passport.session());

// implement an Auth Strategy
passport.use(User.createStrategy());
// serialize and deserialize user data
passport.serializeUser(User.serializeUser() as any);
passport.deserializeUser(User.deserializeUser());

let jwtOptions = {
    jwtFromRequest: ExtractJWT.fromAuthHeaderAsBearerToken(),
    secretOrKey: db.secret,
};

// setup JWT Strategy
let strategy = new JWTStrategy(jwtOptions, function (jwt_payload, done) {
    try {
        const user = User.findById(jwt_payload.id);
        if (user) {
            return done(null, user);
        }
        return done(null, false);
    } catch (error) {
        return done(error, false);
    }
});

passport.use(strategy);

app.use("/", indexRouter);
app.use("/auth", authRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    next(createError(404));
});

export default app;
