// auth.ts
// Harmandeep Kaur
// Student id: 200560512
// Date: 01/12/2023

import express from "express";
let router = express.Router();

// Importing all controller functions
import { loginUser, logoutUser, registerUser } from "../controllers/user";

// POST endpoint to register user
router.post("/register", registerUser);

// POST endpoint to login user
router.post("/login", loginUser);

// GET endpoint to logout user
router.get("/logout", logoutUser);

export default router;
