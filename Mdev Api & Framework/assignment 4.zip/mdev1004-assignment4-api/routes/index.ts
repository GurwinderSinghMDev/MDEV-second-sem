// index.ts
// Harmandeep Kaur
// Student id: 200560512
// Date: 01/12/2023

import express from "express";
let router = express.Router();
import passport from "passport";

// Importing all controller functions
import { addBook, deleteBook, findBookById, listBooks, updateBook } from "../controllers/book";

// GET endpoint to get all books
router.get("/list", passport.authenticate("jwt", { session: false }), listBooks);

// GET endpoint to get book by id
router.get("/find/:id", passport.authenticate("jwt", { session: false }), findBookById);

// POST endpoint to add book in database
router.post("/add", passport.authenticate("jwt", { session: false }), addBook);

// POST endpoint to update book in database
router.post("/update/:id", passport.authenticate("jwt", { session: false }), updateBook);

// DELETE endpoint to delete book from database
router.delete("/delete/:id", passport.authenticate("jwt", { session: false }), deleteBook);

export default router;
