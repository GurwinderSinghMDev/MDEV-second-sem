import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { auth } from "./firebase";

// Components
import CatFacts from "./cat-facts";
import WizardDetail from "./wizard";
import RickAndMortyCharacters from "./rick-and-morty-characters";
import Signup from "./signup";
import Login from "./login";
import Header from "./header";
import Home from "./home";

function App() {
    // use state for managing user
    const [user, setUser] = useState(null);

    // use effect to set a listener for auth state change
    useEffect(() => {
        // Listener from firebase
        const unsubscribe = auth.onAuthStateChanged((authUser) => {
            // if user exists get user efter a second for sign up to allow updating display name
            if (authUser) {
                setTimeout(() => {
                    setUser(auth.currentUser);
                }, 1000);
            } else {
                setUser(null);
            }
        });

        return () => {
            unsubscribe();
        };
    }, []);

    return (
        <BrowserRouter>
            <Header user={user} />
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/cat-facts" element={<CatFacts />} />
                <Route path="/wizard/:id" element={<WizardDetail />} />
                <Route path="/rick-and-morty" element={<RickAndMortyCharacters />} />
                <Route path="/" element={<Home />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;
