import React, { useState, useEffect } from "react";

function CatFacts() {
    const [catFacts, setCatFacts] = useState([]);
    const [loading, setLoading] = useState(true);

    // Use effect to fetch and show cat facts from API
    // Loads data on first load of component
    useEffect(() => {
        fetch("https://cat-fact.herokuapp.com/facts")
            .then((response) => response.json())
            .then((data) => {
                setCatFacts(data);
                setLoading(false);
            })
            .catch((error) => console.error(error));
    }, []);

    return (
        <div className="cat-facts">
            <h2>Cat Facts</h2>
            {loading ? (
                <p>Loading Cat Facts...</p>
            ) : (
                <ul>
                    {catFacts.map((fact) => (
                        <li key={fact._id}>
                            {fact.text}
                            {fact.status.verified && <span className="verified-tag">Verified</span>}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}

export default CatFacts;
