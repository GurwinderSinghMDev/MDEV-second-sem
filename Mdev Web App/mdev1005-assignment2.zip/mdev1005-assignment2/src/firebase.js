import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyCd6fKvyVKd1tDbVf_YVPEClQoNymqoA8Y",
    authDomain: "mdev1005-assignment2.firebaseapp.com",
    projectId: "mdev1005-assignment2",
    storageBucket: "mdev1005-assignment2.appspot.com",
    messagingSenderId: "410409418498",
    appId: "1:410409418498:web:3b0fa69ee395f23743cc1b",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
