import React from "react";
import { Link } from "react-router-dom";
import { auth } from "./firebase";
import { useNavigate } from "react-router-dom";

function Header({ user }) {
    const navigate = useNavigate();

    // Function to handle logout
    const handleLogout = () => {
        auth.signOut();
    };

    // If the user is logged in show Hi, Display name and logout
    // or show login and sign up button
    return (
        <header>
            <div className="header-left" onClick={() => navigate("/")}>
                <span>Assignment 2</span>
            </div>
            <div className="header-right">
                {user ? (
                    <div>
                        <span>Hi, {user.displayName}</span>
                        <button onClick={handleLogout}>Logout</button>
                    </div>
                ) : (
                    <div>
                        <Link to="/login">Login</Link>
                        <Link to="/signup">Sign Up</Link>
                    </div>
                )}
            </div>
        </header>
    );
}

export default Header;
