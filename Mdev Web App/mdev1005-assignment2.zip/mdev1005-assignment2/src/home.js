import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import { collection, getDocs } from "firebase/firestore";
import { Link } from "react-router-dom";
import UnitConverter from "./unit-converter";
import Stopwatch from "./stopwatch";

function Home() {
    // Use states to show data
    const [users, setUsers] = useState([]);
    const [catFact, setCatFact] = useState("");
    const [wizards, setWizards] = useState([]);
    const [characterData, setCharacterData] = useState(null);

    // Use Effect to load data on first load
    useEffect(() => {
        // Function calls to fetch data from APIs
        fetchUsers();
        fetchCatFacts();
        fetchWizards();
        fetchRandomCharacter();
    }, []);

    // Function to fetch user data from firestore database
    const fetchUsers = async () => {
        try {
            const usersCollectionRef = collection(db, "users");
            const usersSnapshot = await getDocs(usersCollectionRef);
            const userList = [];
            usersSnapshot.forEach((doc) => {
                userList.push(doc.data());
            });
            setUsers(userList);
        } catch (error) {
            console.error("Error fetching users:", error);
        }
    };

    // Function to fetch wizards data
    const fetchWizards = () => {
        fetch("https://wizard-world-api.herokuapp.com/Wizards")
            .then((response) => response.json())
            .then((data) => {
                setWizards(data);
            })
            .catch((error) => console.error("Error fetching wizards:", error));
    };

    // Function to fetch cat facts
    const fetchCatFacts = () => {
        fetch("https://cat-fact.herokuapp.com/facts")
            .then((response) => response.json())
            .then((data) => {
                const randomFact = data[Math.floor(Math.random() * data.length)];
                setCatFact(randomFact.text);
            })
            .catch((error) => console.error("Error fetching cat facts:", error));
    };

    // Function to fetch a rick and morty character
    const fetchRandomCharacter = () => {
        const randomNumber = Math.floor(Math.random() * 826) + 1;

        fetch(`https://rickandmortyapi.com/api/character/${randomNumber}`)
            .then((response) => response.json())
            .then((data) => {
                setCharacterData(data);
            })
            .catch((error) => console.error("Error fetching character data:", error));
    };

    return (
        <div>
            <h1>Welcome to the Home Page</h1>

            {/* Widget to show all users */}
            <div className="widget">
                <h2>Users</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map((user, index) => (
                            <tr key={index}>
                                <td>{user.name}</td>
                                <td>{user.email}</td>
                                <td>{user.phoneNumber}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Widget to show a random cat fact */}
            <div className="widget">
                <h2>Cat Fact of the Day</h2>
                <p>{catFact}</p>
                <button className="refresh-button" onClick={fetchCatFacts}>
                    &#8635;
                </button>
                &nbsp;
                <Link to={`/cat-facts`}>Load More</Link>
            </div>

            {/* Widget to show Wizards */}
            <div className="widget">
                <h2>Wizards</h2>
                <table>
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        {wizards.map((wizard, index) => (
                            <tr key={index}>
                                <td>
                                    <Link to={`/wizard/${wizard.id}`}>{wizard.firstName}</Link>
                                </td>
                                <td>
                                    <Link to={`/wizard/${wizard.id}`}>{wizard.lastName}</Link>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Widget to show a random Rick and Morty Character */}
            <div className="widget">
                <h2>Rick and Morty Character</h2>
                {characterData && (
                    <div className="character-container">
                        <img src={characterData.image} alt={characterData.name} />
                        <div>
                            <p>
                                <strong>Name:</strong> {characterData.name}
                            </p>
                            <p>
                                <strong>Status:</strong> {characterData.status}
                            </p>
                            <p>
                                <strong>Species:</strong> {characterData.species}
                            </p>
                            <p>
                                <strong>Gender:</strong> {characterData.gender}
                            </p>
                            <p>
                                <strong>Origin:</strong> {characterData.origin.name}
                            </p>
                            <p>
                                <strong>Location:</strong> {characterData.location.name}
                            </p>
                        </div>
                    </div>
                )}
                <button className="refresh-button" onClick={fetchRandomCharacter}>
                    &#8635;
                </button>
                &nbsp;
                <Link to={`/rick-and-morty`}>Load More</Link>
            </div>

            {/* Widget to show a unit converter */}
            <UnitConverter />

            {/* Widget to show a stopwatch */}
            <Stopwatch />
        </div>
    );
}

export default Home;
