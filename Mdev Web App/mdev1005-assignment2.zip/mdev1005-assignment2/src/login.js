import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { auth } from "./firebase";
import { signInWithEmailAndPassword } from "firebase/auth";

function Login() {
    // use states
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const navigate = useNavigate();

    // function to handle login
    const handleLogin = async (e) => {
        e.preventDefault();
        setPasswordError("");

        // validation
        let valid = true;

        if (password.length < 6) {
            setPasswordError("Password must be at least 6 characters.");
            valid = false;
        }

        if (!valid) {
            return;
        }

        // Login with auth and navigate to home page
        try {
            await signInWithEmailAndPassword(auth, email, password);
            navigate("/");
        } catch (error) {
            setPasswordError(error.message);
        }
    };

    return (
        <div className="signup-container">
            <h1>Login</h1>
            <form onSubmit={handleLogin} className="signup-form">
                <label>Email:</label>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                <label>Password:</label>
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                {passwordError && <div className="error-message">{passwordError}</div>}
                <button type="submit">Login</button>
            </form>
            <p>
                Don't have an account? <Link to="/signup">Sign Up</Link>
            </p>
        </div>
    );
}

export default Login;
