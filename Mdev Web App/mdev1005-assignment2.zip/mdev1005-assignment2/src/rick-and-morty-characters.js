import React, { useEffect, useState } from "react";

function RickAndMortyCharacters() {
    const [characters, setCharacters] = useState([]);

    // use effect to load all rick and morty characters on first load
    useEffect(() => {
        fetch("https://rickandmortyapi.com/api/character")
            .then((response) => response.json())
            .then((data) => {
                setCharacters(data.results);
            });
    }, []);

    return (
        <div className="rick-and-morty-characters">
            <h2>Rick and Morty Characters</h2>
            <div>
                {characters.map((character) => (
                    <div key={character.id} className="widget">
                        <div className="character-container">
                            <img src={character.image} alt={character.name} />
                            <div>
                                <h3>{character.name}</h3>
                                <p>Status: {character.status}</p>
                                <p>Species: {character.species}</p>
                                <p>Type: {character.type}</p>
                                <p>Gender: {character.gender}</p>
                                <p>Origin: {character.origin.name}</p>
                                <p>Location: {character.location.name}</p>
                                <p>
                                    URL:{" "}
                                    <a href={character.url} target="_blank">
                                        Details
                                    </a>
                                </p>
                                <p>Created: {character.created}</p>
                                <h4>Episodes:</h4>
                                <ul>
                                    {character.episode.map((episode, index) => (
                                        <li key={index}>
                                            <a href={episode} target="_blank" rel="noopener noreferrer">
                                                Episode {index + 1}
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default RickAndMortyCharacters;
