import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { auth, db } from "./firebase";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";

function Signup() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [phoneNumber, setPhoneNumber] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmPasswordError, setConfirmPasswordError] = useState("");

    const navigate = useNavigate();

    // function to handle sign up
    const handleSignup = async (e) => {
        e.preventDefault();
        setPasswordError("");
        setConfirmPasswordError("");

        let valid = true;

        if (password.length < 6) {
            setPasswordError("Password must be at least 6 characters.");
            valid = false;
        }

        if (confirmPassword != password) {
            setConfirmPasswordError("Passwords do not match");
            valid = false;
        }

        if (!valid) {
            return;
        }

        try {
            // Sign up with auth
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;

            // update display name in profile
            await updateProfile(user, {
                displayName: name,
            });

            // add user information in firestore database under collection named users
            const usersRef = doc(db, "users", user.uid);
            await setDoc(usersRef, {
                name,
                email,
                phoneNumber,
            });

            // navigate to home screen
            navigate("/");
        } catch (error) {
            setConfirmPasswordError(error.message);
        }
    };
    return (
        <div className="signup-container">
            <h1>Sign Up</h1>
            <form onSubmit={handleSignup} className="signup-form">
                <label>Name:</label>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
                <label>Email:</label>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                <label>Phone Number:</label>
                <input type="number" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
                <label>Password:</label>
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                {passwordError && <div className="error-message">{passwordError}</div>}
                <label>Confirm Password:</label>
                <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                />
                {confirmPasswordError && <div className="error-message">{confirmPasswordError}</div>}
                <button type="submit">Sign Up</button>
            </form>
            <p>
                Already have an account? <Link to="/login">Login</Link>
            </p>
        </div>
    );
}

export default Signup;
