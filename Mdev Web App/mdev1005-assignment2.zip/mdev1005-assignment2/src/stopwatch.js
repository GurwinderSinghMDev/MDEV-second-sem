import React, { useState, useEffect } from "react";

function Stopwatch() {
    const [isRunning, setIsRunning] = useState(false);
    const [elapsedTime, setElapsedTime] = useState(0);

    // use effect to run code block when isRunning status is changed
    useEffect(() => {
        let interval;

        // if is running then add a interval to update seconds
        if (isRunning) {
            interval = setInterval(() => {
                setElapsedTime((prevTime) => prevTime + 1);
            }, 1000);
        } else {
            clearInterval(interval);
        }

        return () => {
            clearInterval(interval);
        };
    }, [isRunning]);

    const startStop = () => {
        setIsRunning(!isRunning);
    };

    const reset = () => {
        setIsRunning(false);
        setElapsedTime(0);
    };

    return (
        <div className="widget stopwatch">
            <h2>Stopwatch</h2>
            <div className="stopwatch-display">
                <span>{formatTime(elapsedTime)}</span>
            </div>
            <div className="stopwatch-controls">
                <button onClick={startStop}>{isRunning ? "Stop" : "Start"}</button>
                <button onClick={reset}>Reset</button>
            </div>
        </div>
    );
}

function formatTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    return `${padZero(hours)}:${padZero(minutes)}:${padZero(remainingSeconds)}`;
}

function padZero(value) {
    return value < 10 ? `0${value}` : value;
}

export default Stopwatch;
