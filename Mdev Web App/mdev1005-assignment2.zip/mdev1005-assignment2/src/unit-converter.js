import React, { useState } from "react";

function UnitConverter() {
    const [value, setValue] = useState("");
    const [category, setCategory] = useState("length");
    const [fromUnit, setFromUnit] = useState("inches");
    const [toUnit, setToUnit] = useState("inches");
    const [result, setResult] = useState("");

    const unitOptions = {
        length: ["inches", "feet", "meters", "centimeters"],
        weight: ["pounds", "kilograms", "grams"],
        temperature: ["fahrenheit", "celsius"],
    };

    // function to handle category change
    const handleCategoryChange = (e) => {
        setCategory(e.target.value);
        setFromUnit(unitOptions[e.target.value][0]);
        setToUnit(unitOptions[e.target.value][0]);
    };

    // function to convert data
    const convert = () => {
        if (!value) {
            return;
        }

        const inputValue = parseFloat(value);

        if (category === "length") {
            const lengthFactors = {
                inches: 0.0254,
                feet: 0.3048,
                meters: 1,
                centimeters: 0.01,
            };

            setResult(((inputValue * lengthFactors[fromUnit]) / lengthFactors[toUnit]).toFixed(2));
        } else if (category === "weight") {
            const weightFactors = {
                pounds: 0.453592,
                kilograms: 1,
                grams: 1000,
            };

            setResult(((inputValue * weightFactors[fromUnit]) / weightFactors[toUnit]).toFixed(2));
        } else if (category === "temperature") {
            if (fromUnit === "celsius" && toUnit === "fahrenheit") {
                setResult(((inputValue * 9) / 5 + 32).toFixed(2));
            } else if (fromUnit === "fahrenheit" && toUnit === "celsius") {
                setResult((((inputValue - 32) * 5) / 9).toFixed(2));
            }
        }
    };

    return (
        <div className="widget">
            <h2>Unit Converter</h2>
            <div>
                <select value={category} onChange={handleCategoryChange}>
                    <option value="length">Length</option>
                    <option value="weight">Weight</option>
                    <option value="temperature">Temperature</option>
                </select>
            </div>
            <div>
                <input
                    type="number"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    placeholder="Enter value"
                    required
                />
            </div>
            <div>
                <select value={fromUnit} onChange={(e) => setFromUnit(e.target.value)}>
                    {unitOptions[category].map((unit) => (
                        <option key={unit} value={unit}>
                            {unit}
                        </option>
                    ))}
                </select>
            </div>
            <div>
                <button onClick={convert}>Convert</button>
            </div>
            <div>
                <span>
                    {result} {toUnit}
                </span>
                <select value={toUnit} onChange={(e) => setToUnit(e.target.value)}>
                    {unitOptions[category].map((unit) => (
                        <option key={unit} value={unit}>
                            {unit}
                        </option>
                    ))}
                </select>
            </div>
        </div>
    );
}

export default UnitConverter;
