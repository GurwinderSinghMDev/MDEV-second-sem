import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

function WizardDetail() {
    const [wizard, setWizard] = useState(null);
    const [loading, setLoading] = useState(true);
    const params = useParams();

    // use effect to fetch wizard data when url param id changes
    useEffect(() => {
        const wizardId = params.id;

        fetch(`https://wizard-world-api.herokuapp.com/Wizards/${wizardId}`)
            .then((response) => response.json())
            .then((response) => {
                setWizard(response);
                setLoading(false);
            })
            .catch((error) => {
                console.error("Error fetching wizard data:", error);
                setLoading(false);
            });
    }, [params.id]);

    return (
        <div className="wizard-detail">
            <h2>Wizard Details</h2>
            {loading ? (
                <p>Loading wizard data...</p>
            ) : wizard ? (
                <div>
                    <p>Name: {`${wizard.firstName} ${wizard.lastName || ""}`}</p>
                    <p>Elixirs:</p>
                    <ul>
                        {wizard.elixirs.map((elixir) => (
                            <li key={elixir.id}>{elixir.name}</li>
                        ))}
                    </ul>
                </div>
            ) : (
                <p>Wizard not found</p>
            )}
        </div>
    );
}

export default WizardDetail;
