package com.example.mdev1005_assignment3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
