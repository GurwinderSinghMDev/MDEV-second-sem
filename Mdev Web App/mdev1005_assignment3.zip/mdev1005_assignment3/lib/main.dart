// main.dart
// Gurwinder Singh
// Student id: 200557497
// Date: 01/12/2023
import 'package:flutter/material.dart';
import 'calculator_screen.dart';
import 'todo_screen.dart';
import 'random_word_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Assignment 3',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/calculator': (context) => CalculatorScreen(),
        '/todo': (context) => TodoScreen(),
        '/randomWord': (context) => RandomWordScreen(),
      },
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Assignment 3'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              'assets/welcome.png',
              width: 200,
              height: 200,
            ),
            SizedBox(height: 20),
            Text(
              'Assignment 3',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/calculator');
                  },
                  child: Text('Calculator'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/todo');
                  },
                  child: Text('Todo'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/randomWord');
                  },
                  child: Text('Random Word'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
