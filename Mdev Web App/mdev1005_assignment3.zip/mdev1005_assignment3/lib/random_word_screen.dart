// random_word_screen.dart
// Harmandeep Kaur
// Student id: 200560512
// Date: 01/12/2023

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RandomWordScreen extends StatefulWidget {
  @override
  _RandomWordScreenState createState() => _RandomWordScreenState();
}

class _RandomWordScreenState extends State<RandomWordScreen> {
  String randomWord = 'Loading...';

  Future<void> fetchRandomWord() async {
    final response = await http.get(Uri.parse('https://random-word-api.herokuapp.com/word'));
    if (response.statusCode == 200) {
      final List<dynamic> jsonResponse = json.decode(response.body);
      setState(() {
        randomWord = jsonResponse[0];
      });
    } else {
      setState(() {
        randomWord = 'Failed to fetch data';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchRandomWord();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Random Word'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Random Word:',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 10),
            Text(
              randomWord,
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                fetchRandomWord();
              },
              child: Text('Refresh'),
            ),
          ],
        ),
      ),
    );
  }
}
